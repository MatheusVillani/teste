package com.example.restapi;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ContaController {
    @Autowired
    private ContaRepository repositorio;
    
        @GetMapping("/contas1")
public List<Conta> listar(@RequestParam(value = "saldo", required = false) Double saldo){
    if (saldo != null) {
        return repositorio.findBySaldo(saldo);
    } else {
        return repositorio.findAll();
    }
}
    
    @GetMapping("/contas/{id}")
    public ResponseEntity<Conta> getTcontaById(@PathVariable(value = "id") Long id) {
        Optional<Conta> tconta = repositorio.findById(id);
    
        if (tconta.isPresent()) {
            return new ResponseEntity<Conta>(tconta.get(), HttpStatus.OK);
        } else {
            throw new ResourceNotFoundException();
        }
    }
    @PostMapping("/contas")
    public Conta postConta(@RequestBody Conta conta) {
        return repositorio.save(conta);
    }

    @PutMapping("/contas/{id}")
    public ResponseEntity<Conta> atualizarConta(@PathVariable(value = "id") Long id, @RequestBody Conta contaDetails) throws ResourceNotFoundException {
        Conta conta = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException());
        
        conta.setId(contaDetails.getId());
        conta.setNome(contaDetails.getNome());
        conta.setSaldo(contaDetails.getSaldo());
        conta.setAgencia(contaDetails.getAgencia());
        
        final Conta contaAtualizada = repositorio.save(conta);
        return ResponseEntity.ok(contaAtualizada);
    }

    @DeleteMapping ("/contas/{id}")
public ResponseEntity<?> deleteConta(@PathVariable(value = "id") Long id) throws ResourceNotFoundException {
    Conta conta = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException());
    
    repositorio.delete(conta);
    
    return ResponseEntity.ok().build();
}
}