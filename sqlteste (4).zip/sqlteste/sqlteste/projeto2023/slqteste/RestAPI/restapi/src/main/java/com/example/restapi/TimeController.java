package com.example.restapi;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TimeController {
    @Autowired
    private TimeRepository repositorio;
    
    @GetMapping("/times1")
   
    public List<Time> listar(@RequestParam(value = "ano", required = false) String ano){
        if (ano != null) {
            return repositorio.findByAno(ano);
        } else {
            return repositorio.findAll();
        }
    }
    @GetMapping("/times")
    public List<Time> listar(){
        return repositorio.findAll();
    }
    
    
    @GetMapping("/times/{id}")
    public ResponseEntity<Time> getTimeById(@PathVariable(value = "id") Long id) {
        Optional<Time> time = repositorio.findById(id);
    
        if (time.isPresent()) {
            return new ResponseEntity<Time>(time.get(), HttpStatus.OK);
        } else {
            throw new ResourceNotFoundException();
        }
    }
    @PostMapping("/times")
    public Time postTime(@RequestBody Time time) {
        return repositorio.save(time);
    }
    
    @DeleteMapping ("/times/{id}")
    public ResponseEntity<?> deleteTime(@PathVariable(value = "id") Long id) {
        Time time = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException());
    
        repositorio.delete(time);
    
        return ResponseEntity.ok().build();
    }
    @PutMapping("/times/{id}")
    public ResponseEntity<Time> updateTime(@PathVariable(value = "id") Long id, @RequestBody Time timeDetails) {
        Time time = repositorio.findById(id).orElseThrow(() -> new ResourceNotFoundException());
    
        time.setId(timeDetails.getId());
        time.setNome(timeDetails.getNome());
        time.setAno(timeDetails.getAno());
    
        time.setCidade(timeDetails.getCidade());
        time.setEstado(timeDetails.getEstado());
    
    
    
        final Time updatedTime = repositorio.save(time);
        return ResponseEntity.ok(updatedTime);
    }
    
    
}
